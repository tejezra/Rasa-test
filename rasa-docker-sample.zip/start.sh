#!/bin/bash

# Start Rasa server and action server
rasa run --enable-api --cors "*" --port 5005 &
rasa run actions --port 5055
